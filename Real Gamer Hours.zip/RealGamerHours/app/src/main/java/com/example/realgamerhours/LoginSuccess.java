package com.example.realgamerhours;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class LoginSuccess extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_success);

    }
}
