package com.example.realgamerhours;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText name, password;
    private TextView numAttentLeft, userRegister;
    private Button userLogin;
    private int counter = 5;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name = (EditText)findViewById(R.id.EnterUserName);
        password = (EditText)findViewById(R.id.EnterUserPassword);
        numAttentLeft = (TextView)findViewById(R.id.numAttentLeft);
        userLogin = (Button)findViewById(R.id.btnLogin);
        userRegister = (TextView)findViewById((R.id.userRegister));

        numAttentLeft.setText("No of attempts remaining: 5");

        Toast.makeText(MainActivity.this, "Firebase connection success",Toast.LENGTH_LONG ).show();

        userLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validateLogin(name.getText().toString(), password.getText().toString());
            }
        });

        userRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, Registration.class));

            }
        });
    }

    private void validateLogin (String userName, String password){
        if ((userName.equals("admin")) && (password.equals("123"))){
            Intent intent = new Intent(MainActivity.this, LoginSuccess.class);
            startActivity(intent);
        }else{
            counter--;

            numAttentLeft.setText("No of attempts remaining: " + String.valueOf(counter));

            if (counter == 0){
                userLogin.setEnabled(false);
            }
        }
    }
}
